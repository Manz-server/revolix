import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Pricing from './components/Pricing';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';
import OrderModal from './components/OrderModal';
import { Package } from './types';

function App() {
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />
      <Hero />
      <Features />
      <Pricing onSelectPackage={setSelectedPackage} />
      <FAQ />
      <Contact />
      <Footer />
      {selectedPackage && (
        <OrderModal
          pkg={selectedPackage}
          onClose={() => setSelectedPackage(null)}
        />
      )}
    </div>
  );
}

export default App;
