export interface Package {
  id: string;
  name: string;
  pricePerGB: number;
  cpu: string;
  badge?: string;
  color: 'cyan' | 'blue' | 'emerald';
}
