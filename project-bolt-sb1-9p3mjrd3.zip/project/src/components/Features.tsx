import { Shield, Zap, RefreshCw, Clock, Database, Wifi } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Anti Down',
    desc: 'Server kami dirancang untuk uptime maksimal. Infrastruktur redundan memastikan server Anda selalu aktif.',
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
  },
  {
    icon: Zap,
    title: 'Anti DDoS',
    desc: 'Perlindungan DDoS tingkat enterprise hingga 100 Gbps. Serangan diblokir sebelum mencapai server Anda.',
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/20',
  },
  {
    icon: RefreshCw,
    title: 'Free 1x Setup',
    desc: 'Tim kami siap membantu setup server Minecraft Anda secara gratis, termasuk konfigurasi awal plugin.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
  },
  {
    icon: Clock,
    title: 'Online 24/7',
    desc: 'Support tersedia sepanjang waktu. Tim kami siap membantu kapan pun Anda membutuhkan.',
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/20',
  },
  {
    icon: Database,
    title: 'Auto Backup Harian',
    desc: 'Backup otomatis setiap hari memastikan data dunia Minecraft Anda aman dari kehilangan.',
    color: 'text-rose-400',
    bg: 'bg-rose-500/10',
    border: 'border-rose-500/20',
  },
  {
    icon: Wifi,
    title: 'Low Latency Connection',
    desc: 'Jaringan fiber optik premium dengan routing optimal untuk pengalaman bermain yang mulus.',
    color: 'text-violet-400',
    bg: 'bg-violet-500/10',
    border: 'border-violet-500/20',
  },
];

export default function Features() {
  return (
    <section id="features" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-gray-900/30 to-transparent pointer-events-none" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-medium mb-4">
            Fitur Unggulan
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Semua yang Anda Butuhkan
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            Setiap paket dilengkapi fitur premium untuk pengalaman hosting terbaik.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f) => (
            <div
              key={f.title}
              className="group relative p-6 rounded-2xl bg-gray-900/50 border border-gray-800/50 hover:border-gray-700/50 transition-all duration-300 hover:bg-gray-900/80 hover:-translate-y-1"
            >
              <div className={`w-12 h-12 rounded-xl ${f.bg} border ${f.border} flex items-center justify-center mb-4`}>
                <f.icon className={`w-6 h-6 ${f.color}`} />
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">{f.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
