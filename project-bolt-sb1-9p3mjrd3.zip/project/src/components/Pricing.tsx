import { useState } from 'react';
import { Check, Zap, Star, Crown } from 'lucide-react';
import { Package } from '../types';

const packages: Package[] = [
  {
    id: 'lite',
    name: 'Lite Package',
    pricePerGB: 6500,
    cpu: 'Intel Platinum 8370C',
    color: 'cyan',
  },
  {
    id: 'medium',
    name: 'Medium Package',
    pricePerGB: 15000,
    cpu: 'AMD EPYC 7433P',
    badge: 'Popular',
    color: 'blue',
  },
  {
    id: 'extreme',
    name: 'Extreme Package',
    pricePerGB: 25000,
    cpu: 'Ryzen 7 3700X',
    color: 'emerald',
  },
];

const features = [
  'Anti Down',
  'Anti DDoS',
  'Free 1x Setup',
  'Online 24/7',
  'Auto Backup Harian',
  'Low Latency Connection',
];

const ramOptions = [1, 2, 4, 6, 8, 10, 12, 16];

const colorMap = {
  cyan: {
    accent: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/30',
    button: 'bg-cyan-500 hover:bg-cyan-400 shadow-cyan-500/25',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    glow: 'hover:shadow-cyan-500/10',
    icon: 'text-cyan-400',
    ring: 'ring-cyan-500/50',
  },
  blue: {
    accent: 'text-blue-400',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/30',
    button: 'bg-blue-500 hover:bg-blue-400 shadow-blue-500/25',
    badge: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    glow: 'hover:shadow-blue-500/10',
    icon: 'text-blue-400',
    ring: 'ring-blue-500/50',
  },
  emerald: {
    accent: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    button: 'bg-emerald-500 hover:bg-emerald-400 shadow-emerald-500/25',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    glow: 'hover:shadow-emerald-500/10',
    icon: 'text-emerald-400',
    ring: 'ring-emerald-500/50',
  },
};

const pkgIcon = { lite: Zap, medium: Star, extreme: Crown };

interface Props {
  onSelectPackage: (pkg: Package & { ram: number }) => void;
}

export default function Pricing({ onSelectPackage }: Props) {
  const [selectedRam, setSelectedRam] = useState<Record<string, number>>({
    lite: 4,
    medium: 4,
    extreme: 4,
  });

  return (
    <section id="pricing" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/[0.02] to-transparent pointer-events-none" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-medium mb-4">
            Paket Hosting
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Pilih Paket Terbaik Anda
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            Semua paket sudah termasuk fitur premium. Pilih sesuai kebutuhan server Minecraft Anda.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {packages.map((pkg) => {
            const c = colorMap[pkg.color];
            const Icon = pkgIcon[pkg.id as keyof typeof pkgIcon];
            const ram = selectedRam[pkg.id];
            const totalPrice = pkg.pricePerGB * ram;

            return (
              <div
                key={pkg.id}
                className={`relative flex flex-col rounded-2xl bg-gray-900/60 border ${
                  pkg.badge ? `${c.border} ring-1 ${c.ring}` : 'border-gray-800/50'
                } p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl ${c.glow} backdrop-blur-sm`}
              >
                {pkg.badge && (
                  <div className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-semibold border ${c.badge}`}>
                    {pkg.badge}
                  </div>
                )}

                {/* Header */}
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <div className={`w-10 h-10 rounded-xl ${c.bg} border ${c.border} flex items-center justify-center mb-3`}>
                      <Icon className={`w-5 h-5 ${c.icon}`} />
                    </div>
                    <h3 className="text-white font-bold text-xl">{pkg.name}</h3>
                    <p className="text-gray-500 text-xs mt-0.5">{pkg.cpu}</p>
                  </div>
                </div>

                {/* Price */}
                <div className="mb-6">
                  <div className="flex items-baseline gap-1">
                    <span className={`text-3xl font-bold ${c.accent}`}>
                      Rp {totalPrice.toLocaleString('id-ID')}
                    </span>
                    <span className="text-gray-500 text-sm">/bulan</span>
                  </div>
                  <p className="text-gray-600 text-xs mt-1">
                    Rp {pkg.pricePerGB.toLocaleString('id-ID')}/GB × {ram}GB
                  </p>
                </div>

                {/* RAM Selector */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm text-gray-400 font-medium">Pilih RAM</span>
                    <span className={`text-sm font-bold ${c.accent}`}>{ram}GB</span>
                  </div>
                  <div className="grid grid-cols-4 gap-1.5">
                    {ramOptions.map((r) => (
                      <button
                        key={r}
                        onClick={() => setSelectedRam((prev) => ({ ...prev, [pkg.id]: r }))}
                        className={`py-2 text-xs font-medium rounded-lg border transition-all duration-150 ${
                          ram === r
                            ? `${c.bg} ${c.border} ${c.accent}`
                            : 'bg-gray-800/50 border-gray-700/50 text-gray-400 hover:border-gray-600 hover:text-gray-300'
                        }`}
                      >
                        {r}GB
                      </button>
                    ))}
                  </div>
                </div>

                {/* Features */}
                <ul className="space-y-2.5 mb-8 flex-1">
                  {features.map((feat) => (
                    <li key={feat} className="flex items-center gap-2.5 text-sm text-gray-300">
                      <div className={`w-4 h-4 rounded-full ${c.bg} flex items-center justify-center flex-shrink-0`}>
                        <Check className={`w-2.5 h-2.5 ${c.icon}`} />
                      </div>
                      {feat}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => onSelectPackage({ ...pkg, ram })}
                  className={`w-full py-3.5 rounded-xl font-semibold text-sm text-black ${c.button} transition-all duration-200 hover:shadow-lg`}
                >
                  Pesan Sekarang — {ram}GB
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
