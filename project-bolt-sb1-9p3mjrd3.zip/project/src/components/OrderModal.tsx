import { useState, useRef, useEffect } from 'react';
import { X, Eye, EyeOff, ShoppingCart } from 'lucide-react';
import { Package } from '../types';

interface Props {
  pkg: Package & { ram: number };
  onClose: () => void;
}

const WA_NUMBER = '6281234567890';

function getPasswordStrength(password: string): { level: 0 | 1 | 2 | 3; label: string; color: string; bar: string } {
  if (!password) return { level: 0, label: '', color: '', bar: '' };
  let score = 0;
  if (password.length >= 8) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score <= 1) return { level: 1, label: 'Password lemah', color: 'text-red-400', bar: 'bg-red-500' };
  if (score === 2 || score === 3) return { level: 2, label: 'Password cukup aman', color: 'text-amber-400', bar: 'bg-amber-400' };
  return { level: 3, label: 'Password sangat kuat', color: 'text-emerald-400', bar: 'bg-emerald-500' };
}

const colorMap = {
  cyan: { border: 'border-cyan-500/30', accent: 'text-cyan-400', bg: 'bg-cyan-500/10', button: 'bg-cyan-500 hover:bg-cyan-400 shadow-cyan-500/25', ring: 'focus:ring-cyan-500/30' },
  blue: { border: 'border-blue-500/30', accent: 'text-blue-400', bg: 'bg-blue-500/10', button: 'bg-blue-500 hover:bg-blue-400 shadow-blue-500/25', ring: 'focus:ring-blue-500/30' },
  emerald: { border: 'border-emerald-500/30', accent: 'text-emerald-400', bg: 'bg-emerald-500/10', button: 'bg-emerald-500 hover:bg-emerald-400 shadow-emerald-500/25', ring: 'focus:ring-emerald-500/30' },
};

export default function OrderModal({ pkg, onClose }: Props) {
  const [gmail, setGmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const overlayRef = useRef<HTMLDivElement>(null);

  const c = colorMap[pkg.color];
  const strength = getPasswordStrength(password);
  const totalPrice = pkg.pricePerGB * pkg.ram;

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  const handleUsernameChange = (val: string) => {
    setUsername(val.replace(/ /g, '_'));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = encodeURIComponent(
      `Halo RevolixHost, saya ingin membeli hosting.\n\n` +
      `Paket: ${pkg.name}\n` +
      `RAM: ${pkg.ram}GB\n` +
      `CPU: ${pkg.cpu}\n` +
      `Harga: Rp ${totalPrice.toLocaleString('id-ID')}/bulan\n` +
      `Gmail: ${gmail}\n` +
      `Username: ${username}`
    );
    window.open(`https://wa.me/${WA_NUMBER}?text=${message}`, '_blank');
  };

  const isValid = gmail.trim() && username.trim() && password.length >= 6;

  return (
    <div
      ref={overlayRef}
      onClick={(e) => { if (e.target === overlayRef.current) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in"
    >
      <div className={`relative w-full max-w-md bg-gray-900 rounded-2xl border ${c.border} shadow-2xl max-h-[90vh] overflow-y-auto`}>
        {/* Header */}
        <div className={`sticky top-0 flex items-center justify-between p-5 border-b border-gray-800/70 bg-gray-900 rounded-t-2xl`}>
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl ${c.bg} border ${c.border} flex items-center justify-center`}>
              <ShoppingCart className={`w-4 h-4 ${c.accent}`} />
            </div>
            <div>
              <h2 className="text-white font-bold text-base">Form Pemesanan</h2>
              <p className={`text-xs ${c.accent}`}>{pkg.name} — {pkg.ram}GB RAM</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-gray-500 hover:text-white transition-colors rounded-lg hover:bg-gray-800">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Order summary */}
        <div className={`mx-5 mt-5 p-4 rounded-xl ${c.bg} border ${c.border}`}>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <span className="text-gray-500 text-xs">Paket</span>
              <p className="text-white font-medium">{pkg.name}</p>
            </div>
            <div>
              <span className="text-gray-500 text-xs">RAM</span>
              <p className="text-white font-medium">{pkg.ram}GB</p>
            </div>
            <div>
              <span className="text-gray-500 text-xs">CPU</span>
              <p className="text-white font-medium text-xs">{pkg.cpu}</p>
            </div>
            <div>
              <span className="text-gray-500 text-xs">Total</span>
              <p className={`font-bold ${c.accent}`}>Rp {totalPrice.toLocaleString('id-ID')}/bln</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="p-3.5 rounded-xl bg-gray-800/40 border border-gray-700/40 text-xs text-gray-400 leading-relaxed">
            Isi username dan Gmail bebas untuk login panel hosting. Pastikan Gmail aktif agar mudah menerima informasi akun.
          </div>

          {/* Gmail */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">Gmail</label>
            <input
              type="email"
              value={gmail}
              onChange={(e) => setGmail(e.target.value)}
              placeholder="contoh@gmail.com"
              required
              className={`w-full px-4 py-3 rounded-xl bg-gray-800/60 border border-gray-700/50 text-white placeholder-gray-600 text-sm transition-all outline-none focus:ring-2 ${c.ring} focus:border-transparent`}
            />
          </div>

          {/* Username */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => handleUsernameChange(e.target.value)}
              placeholder="Username_Anda"
              required
              className={`w-full px-4 py-3 rounded-xl bg-gray-800/60 border border-gray-700/50 text-white placeholder-gray-600 text-sm transition-all outline-none focus:ring-2 ${c.ring} focus:border-transparent`}
            />
            {username && (
              <p className="text-xs text-gray-500 mt-1">Spasi otomatis diubah menjadi "_"</p>
            )}
          </div>

          {/* Password */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">Password</label>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min. 6 karakter"
                required
                minLength={6}
                className={`w-full px-4 py-3 pr-11 rounded-xl bg-gray-800/60 border border-gray-700/50 text-white placeholder-gray-600 text-sm transition-all outline-none focus:ring-2 ${c.ring} focus:border-transparent`}
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
              >
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {/* Strength indicator */}
            {password && (
              <div className="mt-2">
                <div className="flex gap-1 mb-1.5">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                        strength.level >= i ? strength.bar : 'bg-gray-700'
                      }`}
                    />
                  ))}
                </div>
                <p className={`text-xs font-medium ${strength.color}`}>{strength.label}</p>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={!isValid}
            className={`w-full py-3.5 rounded-xl font-semibold text-sm text-black ${c.button} transition-all duration-200 hover:shadow-lg disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2`}
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            Kirim via WhatsApp
          </button>
        </form>
      </div>
    </div>
  );
}
