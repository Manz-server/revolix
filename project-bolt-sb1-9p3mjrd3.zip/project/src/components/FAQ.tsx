import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    q: 'Berapa lama proses aktivasi server setelah pembayaran?',
    a: 'Server Anda akan aktif dalam kurang dari 1 menit setelah pembayaran dikonfirmasi. Tim kami siap membantu setup awal secara gratis.',
  },
  {
    q: 'Apakah bisa upgrade atau downgrade paket?',
    a: 'Ya, Anda dapat upgrade atau downgrade kapan saja. Perbedaan harga akan dihitung secara proporsional sesuai sisa masa aktif.',
  },
  {
    q: 'Versi Minecraft apa saja yang didukung?',
    a: 'Kami mendukung semua versi Minecraft Java Edition, Bedrock Edition, serta berbagai server software seperti Paper, Spigot, Forge, Fabric, dan lainnya.',
  },
  {
    q: 'Bagaimana dengan perlindungan DDoS?',
    a: 'Semua server dilindungi sistem anti-DDoS enterprise hingga 100 Gbps. Serangan dideteksi dan dimitigasi secara otomatis sebelum memengaruhi server Anda.',
  },
  {
    q: 'Apakah tersedia panel kontrol untuk mengelola server?',
    a: 'Ya, setiap server dilengkapi panel Pterodactyl yang modern dan mudah digunakan. Anda dapat start, stop, restart, upload file, dan monitor server dari panel.',
  },
  {
    q: 'Bagaimana cara melakukan backup dan restore?',
    a: 'Backup otomatis dilakukan setiap hari. Anda juga dapat membuat backup manual kapan saja dari panel. Restore dapat dilakukan dengan satu klik.',
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section id="faq" className="py-24 relative">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-medium mb-4">
            FAQ
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Pertanyaan Umum</h2>
          <p className="text-gray-400">Temukan jawaban atas pertanyaan yang sering ditanyakan pelanggan kami.</p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className={`rounded-xl border transition-all duration-200 overflow-hidden ${
                open === i ? 'border-cyan-500/30 bg-gray-900/80' : 'border-gray-800/50 bg-gray-900/40'
              }`}
            >
              <button
                className="w-full flex items-center justify-between p-5 text-left"
                onClick={() => setOpen(open === i ? null : i)}
              >
                <span className={`font-medium text-sm pr-4 ${open === i ? 'text-white' : 'text-gray-300'}`}>
                  {faq.q}
                </span>
                <ChevronDown
                  className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${
                    open === i ? 'rotate-180 text-cyan-400' : 'text-gray-500'
                  }`}
                />
              </button>
              {open === i && (
                <div className="px-5 pb-5">
                  <p className="text-gray-400 text-sm leading-relaxed">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
